/**
 * 
 */
package Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

/**
 * @author Zuber Qureshi
 * @version 1.0
 * @ description Page created to update the existing pet details
 */

public class ModifyPetDetails {
		
	  	WebDriver driver;
	  	By NameCell;
	  	By StatusCell;
				
	  	//Function to Set Up Xpaths for Updating the Pet Details
		public void setUpPage(int row){
			NameCellToUpdate = By.xpath("//tr["+row+"]/td[1]");
			StatusCellToUpdate = By.xpath("//tr["+row+"]/td[2]");
			NameCell = By.xpath("//tr["+row+"]/td[1]/input");
			StatusCell = By.xpath("//tr["+row+"]/td[2]/input");
		}
		
		//Function to Update the Pet Details by pressing the Enter key
		public void UpdateByPressingEnter(String UpdateName, String UpdateStatus, int row){
			try{
			if(row>0){
			
			driver.findElement(NameCellToUpdate).click();
			driver.findElement(NameCell).clear();
			driver.findElement(NameCell).sendKeys(UpdateName);
			driver.findElement(NameCell).sendKeys(Keys.ENTER);
			
			WebDriverWait wait =  new WebDriverWait(driver,10);
			wait.until(ExpectedConditions.elementToBeClickable(StatusCellToUpdate));
			
			driver.findElement(StatusCellToUpdate).click();
			driver.findElement(StatusCell).clear();
			driver.findElement(StatusCell).sendKeys(UpdateStatus);
			driver.findElement(StatusCell).sendKeys(Keys.ENTER);	
			
			}
			else{
				Assert.fail("The pet you are tying to update is not found in the petstore");
				
			}
			}catch(Exception e){
				e.getMessage();				
			}
			
		}
		
		int row_num;
		List<WebElement> table_rows1;
		List<WebElement> table_col;
		By NameCellToUpdate;
		By StatusCellToUpdate;
		By TBody;
		
		//Function to find the Row No. of the pet to be Modified
		public int RowNoToUpdate(String Name, String Status,WebDriver driver){
			try{
			this.driver=driver;
			Thread.sleep(1000);
			TBody = By.xpath("//table[@class='table table-hover']/tbody[@class='pet-list']");
			table_rows1= driver.findElement(TBody).findElements(By.tagName("tr"));
			int tr1 = table_rows1.size();
			
			for(int i=0;i<tr1;++i){
				table_col = table_rows1.get(i).findElements(By.tagName("td"));
				if(table_col.get(0).getText().equals(Name)){
					if(table_col.get(1).getText().equals(Status)){
					row_num = i+1;
					
					break;
					}
				}
				
	 		}
						
		}catch(Exception e){
			//e.printStackTrace();
			TBody = By.xpath("//table[@class='table table-hover']/tbody[@class='pet-list']");
			table_rows1= driver.findElement(TBody).findElements(By.tagName("tr"));
			int tr1 = table_rows1.size();
			
			for(int i=0;i<tr1;++i){
				table_col = table_rows1.get(i).findElements(By.tagName("td"));
				if(table_col.get(0).getText().equals(Name)){
					if(table_col.get(1).getText().equals(Status)){
					row_num = i+1;
			
					break;
					}
				}
				
		}
			
		}
			return row_num;
		}		
		
		
		WebElement name;
		WebElement status;
		
		//Function to Validate the Modified Pet Details
		public void validateUpdate(int getRow,String UpdatedName,String UpdatedStatus) throws InterruptedException
		{
			try {
				WebDriverWait wait = new WebDriverWait(driver, 10);
				Thread.sleep(1000);
				name = driver.findElement(By.xpath("//table[@class='table table-hover']/tbody[@class='pet-list']//tr["+getRow+"]//td[1]"));
				status = driver.findElement(By.xpath("//table[@class='table table-hover']/tbody[@class='pet-list']//tr["+getRow+"]//td[2]"));
				String actualName = name.getText();
				String actualStatus = status.getText();
				Assert.assertEquals(actualName, UpdatedName,"Name is not being updated as expected");
				Assert.assertEquals(actualStatus, UpdatedStatus,"Status is not being updated as expected");
			} catch (Exception  e) {
						
				Thread.sleep(1500);
				name = driver.findElement(By.xpath("//table[@class='table table-hover']/tbody[@class='pet-list']//tr["+getRow+"]//td[1]"));
				status = driver.findElement(By.xpath("//table[@class='table table-hover']/tbody[@class='pet-list']//tr["+getRow+"]//td[2]"));
								
				String actualName = name.getText();
				System.out.println(actualName);
				
				String actualStatus = status.getText();
				
				Assert.assertEquals(actualName, UpdatedName,"Name is not being updated as expected");
				Assert.assertEquals(actualStatus, UpdatedStatus,"Status is not being updated as expected");
			}
			
		}
		
		//Function to update the Details by pressing the ESC button
		public void UpdateByPressingESC(String UpdateName, String UpdateStatus, int row){
			try{
			if(row>0){
			
			driver.findElement(NameCellToUpdate).click();
			driver.findElement(NameCell).clear();
			driver.findElement(NameCell).sendKeys(UpdateName);
			driver.findElement(NameCell).sendKeys(Keys.ESCAPE);
			
			WebDriverWait wait =  new WebDriverWait(driver,10);
			wait.until(ExpectedConditions.elementToBeClickable(StatusCellToUpdate));
			
			driver.findElement(StatusCellToUpdate).click();
			driver.findElement(StatusCell).clear();
			driver.findElement(StatusCell).sendKeys(UpdateStatus);
			driver.findElement(StatusCell).sendKeys(Keys.ESCAPE);	
			
			}
			else{
				Assert.fail("The pet you are tying to update is not found in the petstore");
				
			}
			}catch(Exception e){
				e.getMessage();				
			}
			
		}
		
		//Function to Update the Pet Details by clicking on any open area on web page
		public void UpdateByClickingOnOpenArea(String UpdateName, String UpdateStatus, int row){
			try{
			if(row>0){
			System.out.println(UpdateStatus);
			driver.findElement(NameCellToUpdate).click();
			driver.findElement(NameCell).clear();
			driver.findElement(NameCell).sendKeys(UpdateName);
			driver.findElement(By.xpath("//h3[text()='List of Pets']")).click();
			
			WebDriverWait wait =  new WebDriverWait(driver,10);
			wait.until(ExpectedConditions.elementToBeClickable(StatusCellToUpdate));
			
			driver.findElement(StatusCellToUpdate).click();
			driver.findElement(StatusCell).clear();
			driver.findElement(StatusCell).sendKeys(UpdateStatus);
			driver.findElement(StatusCell).sendKeys(Keys.ESCAPE);	
			driver.findElement(By.xpath("//h3[text()='List of Pets']")).click();
			}
			else{
				Assert.fail("The pet you are tying to update is not found in the petstore");
				
			}
			}catch(Exception e){
				e.getMessage();				
			}
			
		}
}
