/**
 * 
 */
package Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

/**
 * @author Zuber Qureshi 
 * @desciption Page to Add pets using erither click or by hitting ENTER
 * @version 1.0
 */
public class AddPets {
	
	WebDriver driver;
	SoftAssert assert1;
	By ActualPetName;
	By TBody;
	
	@CacheLookup
	@FindBy(xpath="//input[@class='form-control pet-name']")
	WebElement PetName;

	@CacheLookup
	@FindBy(xpath="//input[@class='form-control pet-status']")
	WebElement PetStatus;
	
	@CacheLookup
	@FindBy(xpath="//button[@id='btn-create']")
	WebElement Createbtn;
		
	//Constructor to initialize the POM objects	
	public AddPets(WebDriver driver){
		PageFactory.initElements(driver, this);
		assert1 = new SoftAssert();
		this.driver = driver;
		
	}
	
	int trows_prev;
	int trows_afterupdate;
	List<WebElement> table_rows;
	
	//Function to Add Pet By CLicking on Enter button
	public void AddPetByClick(String PetName1, String PetStatus1){
		try {
			TBody = By.xpath("//table[@class='table table-hover']/tbody[@class='pet-list']");
			table_rows=driver.findElement(TBody).findElements(By.tagName("tr"));
		
			trows_prev = table_rows.size();
			PetName.sendKeys(PetName1);
			PetStatus.sendKeys(PetStatus1);
			Createbtn.click();						
		
			}catch (Exception e) {
				e.printStackTrace();
			}
	}
	
	//Function to check the added pet in complete webtable
	public void ValidateAddedPet(String PetName1, String PetStatus1){
		try{
		
		//Below 2 lines are used to find the added pet in the complete webtable
		PetDetails PetDet = new PetDetails(driver);
		PetDet.TableData(PetName1, PetStatus1);
					
	}catch(Exception e)	{
		e.getMessage();
	}
}
	 
	//Function to check the Added pet on Specific row
	public void ValidateAddOrUpdatePets(String PetName1, String PetStatus1) throws InterruptedException{
	try{
	
	WebDriverWait wait = new WebDriverWait(driver,10);
	Thread.sleep(1000);	
	TBody = By.xpath("//table[@class='table table-hover']/tbody[@class='pet-list']");
	//wait.until(ExpectedConditions.stalenessOf((WebElement) TBody));
	//wait.until(ExpectedConditions.visibilityOf((WebElement) TBody));
	table_rows=driver.findElement(TBody).findElements(By.tagName("tr"));

	trows_afterupdate = table_rows.size();
					
	//Below code directly searches for the added pet in last row
	if(trows_prev<trows_afterupdate){
		if(driver.findElement(By.xpath("//tr["+ trows_afterupdate +"]//following::span[contains(text(),'"+ PetName1 +"')]")).isDisplayed()){
			System.out.println("Pet "+ PetName1 + " is present as expected");
		}
		else{
			assert1.fail("Pat Name is not found in webatble. It could be that the pet is not added successfully");
		}
		
		////tr[2]//following::span[contains(text(),'Mickey')] - Sample xpath
		
		if(driver.findElement(By.xpath("//tr["+ trows_afterupdate +"]//following::span[contains(text(),'"+ PetStatus1 +"')]")).isDisplayed()){
			System.out.println("Pet "+ PetStatus1 + " is present as expected");
		}
		else{
			assert1.fail("Pat status is not found in webatble. It could be that the pet is not added successfully");
		}
		}
	else{
		assert1.fail("Added pet is not seen in webtable. It could be that the pet is not added successfully");
	}
assert1.assertAll();

	}catch(StaleElementReferenceException e){
		
		WebDriverWait wait = new WebDriverWait(driver,10);
		
		TBody = By.xpath("//table[@class='table table-hover']/tbody[@class='pet-list']");
		wait.until(ExpectedConditions.stalenessOf((WebElement) TBody));
		wait.until(ExpectedConditions.visibilityOf((WebElement) TBody));
		table_rows=driver.findElement(TBody).findElements(By.tagName("tr"));

		trows_afterupdate = table_rows.size();
						
		//Below code directly searches for the added pet in last row
		if(trows_prev<trows_afterupdate){
			if(driver.findElement(By.xpath("//tr["+ (trows_afterupdate) +"]//following::span[contains(text(),'"+ PetName1 +"')]")).isDisplayed()){
				System.out.println("Pet "+ PetName1 + " is present as expected");
			}
			else{
				assert1.fail("Pat Name is not found in webatble. It could be that the pet is not added successfully");
			}
			
			////tr[2]//following::span[contains(text(),'Mickey')] - Sample xpath
			
			if(driver.findElement(By.xpath("//tr["+ trows_afterupdate +"]//following::span[contains(text(),'"+ PetStatus1 +"')]")).isDisplayed()){
				System.out.println("Pet "+ PetStatus1 + " is present as expected");
			}
			else{
				assert1.fail("Pat status is not found in webatble. It could be that the pet is not added successfully");
			}
			}
		else{
			assert1.fail("Added pet is not seen in webtable. It could be that the pet is not added successfully");
		}
	assert1.assertAll();
	}
	}
	
	//Function to Add pet by using Tab and Enter Key
	public void TabUseAndEnterKeyToAddPet(String PetName1, String PetStatus1){
		
		PetName.click();		
		assert1.assertEquals(driver.switchTo().activeElement(),PetName,"PetName text box is not focused");
		PetName.sendKeys(PetName1);
		
		PetName.sendKeys(Keys.TAB);
		assert1.assertEquals(driver.switchTo().activeElement(), PetStatus,"Pet status is not focused");
		PetStatus.sendKeys(PetStatus1);
		
		PetStatus.sendKeys(Keys.TAB);
		assert1.assertEquals(driver.switchTo().activeElement(), Createbtn,"Create button is not focused");
		Createbtn.sendKeys(Keys.ENTER);
	}
	
	
	List<WebElement> trrows;
	
	String ActualName;
	String ActualStatus;
		
	//Function to Validate Mandatory fileds like NAme & Status of Pet
	public void ValidateMandatoryFields(){
		try{
		
			TBody = By.xpath("//table[@class='table table-hover']/tbody[@class='pet-list']");
			trrows=driver.findElement(TBody).findElements(By.tagName("tr"));
			
			int prev_rw_cnt = trrows.size();
							
			Createbtn.click();
		
			Thread.sleep(1000);
		
			TBody = By.xpath("//table[@class='table table-hover']/tbody[@class='pet-list']");
			trrows=driver.findElement(TBody).findElements(By.tagName("tr"));

			int afterAdd_rw_cnt = trrows.size();
			
			if(prev_rw_cnt<afterAdd_rw_cnt){
				List<WebElement> tdCol = trrows.get(afterAdd_rw_cnt-1).findElements(By.tagName("td"));
				ActualName = tdCol.get(0).getText();
				ActualStatus = tdCol.get(1).getText();	
								
				if(ActualName.isEmpty()){
					assert1.fail("Blank Name is entered which is not as expected as Name filed is mandatory");
				}
				if(ActualStatus.isEmpty()){
					assert1.fail("Blank Status is entered which is not as expected as Status filed is mandatory");
				}
			}
			else{
				assert1.fail("Row is not added to the Web Table");
			}
			assert1.assertAll();
		}catch(Exception e){
			e.getMessage();
			e.printStackTrace();
		}
	}
}