/**
 * 
 */
package Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.asserts.SoftAssert;

/**
 * @author Zuber Qureshi 
 * @desciption To validate all the pets present on a page
 * @version 1.0
 */

public class PetDetails {

	WebDriver driver;
	By TableHeaderCell;	
	SoftAssert assert2;
	
	@CacheLookup
	@FindBy(xpath="//table[@class='table table-hover']/tbody[@class='pet-list']")
	WebElement TBody;

	@CacheLookup
	@FindBy(xpath="//table[@class='table table-hover']")
	WebElement Table;

	@CacheLookup
	@FindBy(xpath="//h3[text()='List of Pets']")
	WebElement ListOfTableHeader;
	
//Constructor to setup the POM
public PetDetails(WebDriver driver){
	try{
	PageFactory.initElements(driver, this);
	
	TableHeaderCell = By.xpath("//thead[@class='thead-default']/tr[1]/th");
	this.driver = driver;
	assert2 = new SoftAssert();
	}catch(Exception e){
		e.printStackTrace();
	}
}
	

//Function to check the table heading
public void TableHeading(){
	try{
		List<WebElement> tabelheader = Table.findElements(TableHeaderCell);
		assert2.assertEquals(tabelheader.get(0).getText().trim(),"Name","Name header filed is not as expected");
		assert2.assertEquals(tabelheader.get(1).getText().trim(),"Status","Status header filed is not as expected");
		assert2.assertEquals(tabelheader.get(2).getText().trim(),"Action","Action header field is not as expected");
		assert2.assertAll();			
}catch(Exception e){
	e.printStackTrace();
	}		
}

//Function to Validate the data in complete web table
public void TableData(String PetName,String Status){
try{
	Thread.sleep(1000);
	List<WebElement> table_rows = TBody.findElements(By.tagName("tr"));
	int row_count = table_rows.size();
	int flag1 = 0;	
	
	for(int i=0;i<row_count;++i){
	//for executing the script for complete webtable
	
	//for(int i=0;i<4;++i){
		
		List<WebElement> table_cols = table_rows.get(i).findElements(By.tagName("td"));
		if(table_cols.get(0).getText().trim().equals(PetName.trim())){							
			System.out.println("The pet name is as expected");
				if(table_cols.get(1).getText().trim().equals(Status.trim())){
						System.out.println("The Pet Status is as expected");
						flag1=1;
						break;
				}
			}		
		}

if(flag1==0){
	assert2.fail("Your pet details are not found as expected in webtable");;
		}
	assert2.assertAll();
}catch(Exception e){
	e.printStackTrace();
}
}

//Function to Validate the heading on webpage
public void ListOfTableHead(){
	if(ListOfTableHeader.isDisplayed()){
		System.out.println("List of pets heading is as expected");
	}
	else{
	assert2.fail("The List Of Pets is not found on webpage");
	}
	assert2.assertAll();
}
}

