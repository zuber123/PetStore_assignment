package Petstore_Package;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

/**
 * @author Akash Sinha 
 * @desciption This Class is having all the Tests which are related to this assignment
 * @version 1.0
 */
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import PageObjaectModel_Package.PetStore_Header;
import PageObjaectModel_Package.PetStore_HomePage;
import PageObjaectModel_Package.PetStore_PetTable;
import PageObjaectModel_Package.PetStore_UpdatePet;
import Utility_Package.BrowserFactory;
import Utility_Package.DataProviderPet;

public class Petstore_TestCases {
	
	WebDriver driver;
	String URL;
	String Browser;
		
	@BeforeTest
	public void ReadConfigFile() throws IOException{
		try {
			Properties prop = new Properties();
			FileInputStream ConfigFile = new FileInputStream(System.getProperty("user.dir")+"\\src\\DataTable\\ConfigFile.properties");
			prop.load(ConfigFile);
			URL = prop.getProperty("URL");
			Browser = prop.getProperty("Browser");
			//DriverPath=prop.getProperty(System.getProperty("user.dir")+"\\src\\Driver\\");
		} catch (FileNotFoundException e) {		
			e.printStackTrace();
		}
	}
	/**
	 * @author Akash Sinha 
	 * @desciption To Open Browser and launch URL
	 * @version 1.0
	 */
	@BeforeMethod
	public void openBrowser()
	{
		//Browserfactory class which will take the driver name and URL and open that particular driver and URL
		BrowserFactory BF = new BrowserFactory();
		driver = BF.selectBrowser(Browser,URL);
		
		
	}
	
	/**
	 * @author Akash Sinha 
	 * @desciption To Close Browser
	 * @version 1.0
	 */
	@AfterMethod
	public void closeBrowser()
	{
		//Quit Driver
		driver.quit();
	}
	
	/**
	 * @author Akash Sinha 
	 * @desciption As a pet store user I want to see the current date displayed on the top banner so that I can easily see it.
	 * Acceptance Criteria: 
	 * 1. Date is displayed on the format DD-MM-YYYY, ie: 01-12-2016
	 * 2. The background color of the banner is black
	 * @version 1.0
	 * @throws Throwable 
	 */
	@Test
	public void US001_HeadeValidaiton()
	{
		//This Line is for Soft Assertion which will be used for validation
		SoftAssert assertion = new SoftAssert();
		
		//initiate object of HeaderValidation class
		PetStore_Header PH = new PetStore_Header(driver);
		
		//get Expected Date
		String ExpectedDate = PH.getExpectedDate();
		
		//get Actual Date
		String ActualDate = PH.getActualDate();
		
		//Comparing the Expected and Actual Date using Soft Assert
		assertion.assertEquals(ActualDate, ExpectedDate,"Dates are not matched. Actual Date is "+ActualDate+" and Expected Date is "+ExpectedDate);
		
		//get Actual Color
		String ActualColor = PH.getActualColor();
		
		//get Expected Color
		String ExpectedColor = PH.getExpectedColor();
		
		//Comparing the Expected and Actual Background using Soft Assert
		assertion.assertEquals(ActualColor, ExpectedColor,"Colors are not matched. Actual color is "+ActualColor+" and Expected color is "+ExpectedColor);
		
		//getLocation
		PH.getLocation();
		
		//Giving the consolidated results of all the Assert use in this Test Case
		assertion.assertAll();
		
	}
	/**
	 * @author Akash Sinha 
	 * @desciption As a pet store user I want to see my current pets so that I can view all my pets in one page.
	 * Acceptance Criteria: 
	 * 1. List of pets displayed in a table like component
	 * 2. User need to be able to easily identify my pets Name and Status
	 * @version 1.0
	 */
	@Test(dataProvider="PetDetailsView")
	public void US002_ViewPets(String Name,String Status){
			
			PetStore_PetTable PPT = new PetStore_PetTable(driver);
			PetStore_UpdatePet PU = new PetStore_UpdatePet(driver);
			PPT.TableHeading();
			int rowNum = PU.getRowNum(Name, Status);
			PPT.validatePetNameStatus(rowNum,Name,Status);
			PPT.ListOfPetsHeader();
		}
	
	/**
	 * @author Akash Sinha 
	 * @desciption As a pet store user I want to be able to add a new pet so that I can add new pets to my collection
	 * Acceptance Criteria: 
	 * 1. Name and Status should be mandatory fields to add a new pet.
	 * 2. After filling the form, adding a new pet should be possible by clicking on a Create button.
	 * @version 1.0
	 */
	@Test(dataProvider = "PetDataAdd")
	public void US003_AddPetCreateButton(String Name, String Status)
	{
		int beforeRowCount;
		int rowCount;
		By table;
		int afterRowCount;
		//This Line is for Soft Assertion which will be used for validation
		
		
		PetStore_HomePage PH = new PetStore_HomePage(driver);
		
		beforeRowCount = PH.getWebtableRowcount();
		rowCount = beforeRowCount+1;
		PH.enterPetDetails(Name, Status);
		
		table = By.xpath("//table[@class='table table-hover']/tbody/tr["+rowCount+"]");
		
		PH.waitWhenVisible(table, 10);
		afterRowCount = PH.getWebtableRowcount();
		PH.validateRowCount(beforeRowCount, afterRowCount);		
		PH.validatePetEntry(Name, Status, rowCount);
		
	}
	
	/**
	 * @author Akash Sinha 
	 * @desciption As a pet store user I want to be able to add a new pet so that I can add new pets to my collection
	 * Acceptance Criteria: 
	 * 1. Name and Status should be mandatory fields to add a new pet.
	 * 2. After filling the form, adding a new pet should be possible by typing the keyboard Enter key
	 * @version 1.0
	 */
	@Test(dataProvider = "PetDataAdd")
	public void US003_AddPetEnterKey(String Name, String Status)
	{
		int beforeRowCount;
		int rowCount;
		By table;
		int afterRowCount;
		//This Line is for Soft Assertion which will be used for validation
		
		
		PetStore_HomePage PH = new PetStore_HomePage(driver);
		
		beforeRowCount = PH.getWebtableRowcount();
		
		rowCount = beforeRowCount+1;
		
		PH.enterPetDetailsEnter(Name, Status);
		
		table = By.xpath("//table[@class='table table-hover']/tbody/tr["+rowCount+"]");
		
		PH.waitWhenVisible(table, 10);
		afterRowCount = PH.getWebtableRowcount();
		PH.validateRowCount(beforeRowCount, afterRowCount);		
		PH.validatePetEntry(Name, Status, rowCount);
		
	}
	
	/**
	 * @author Akash Sinha 
	 * @desciption As a pet store user I want to be able to add a new pet so that I can add new pets to my collection
	 * Acceptance Criteria: 
	 * 1. The following sequence should be respected in terms of accessibility (using the tab key)
	 * PetName --> PetStatus --> CreateButton
	 * @version 1.0
	 */	
	@Test
	public void US003_AddPetEnterEmpty()
	{
		String Name = "";
		String Status = "";
		int beforeRowCount;
		int rowCount;
		By table;
		int afterRowCount;
		//This Line is for Soft Assertion which will be used for validation
		
		
		PetStore_HomePage PH = new PetStore_HomePage(driver);
		
		beforeRowCount = PH.getWebtableRowcount();
		
		rowCount = beforeRowCount+1;
		
		PH.enterPetDetailsEnter(Name, Status);
		
		table = By.xpath("//table[@class='table table-hover']/tbody/tr["+rowCount+"]");
		
		PH.waitWhenVisible(table, 10);
		afterRowCount = PH.getWebtableRowcount();
		PH.validateRowCount(beforeRowCount, afterRowCount);		
		PH.validatePetEntryEmpty(Name, Status, rowCount);
		
		
	}
	
	/**
	 * @author Akash Sinha 
	 * @desciption As a pet store user I want to be able to add a new pet so that I can add new pets to my collection
	 * Acceptance Criteria: 
	 * 1. The following sequence should be respected in terms of accessibility (using the tab key)
	 * PetName --> PetStatus --> CreateButton
	 * @version 1.0
	 */
	@Test
	public void US003_CheckAccessibilityTab()
	{
		PetStore_HomePage PH = new PetStore_HomePage(driver);
		PH.verifyPetAccesbility();
	}
	
	/**
	 * @author Akash Sinha 
	 * @desciption As a pet store user I want modifying my existing pets so that I can update their name or/and status.
	 * Acceptance Criteria: 
	 * 1. Pet edit should be possible by clicking on pet name or pet status
	 * 2. Pressing the Enter key => Changes should be saved.
	 * @version 1.0
	 */
	
	@Test(dataProvider="PetDetailsUpdate")
	public void US004_UpdatePetsEnter(String CurrentName,String UpdatedName,String CurrentStatus,String UpdatedStatus) throws Throwable
	{
		PetStore_UpdatePet PU = new PetStore_UpdatePet(driver);
		int rowNum = PU.getRowNum(CurrentName,CurrentStatus);
		PU.updatePetNameStatusEnter(rowNum,UpdatedName,UpdatedStatus);
		PU.validateUpdate(rowNum,UpdatedName,UpdatedStatus);
		
	}
	
	/**
	 * @author Akash Sinha 
	 * @desciption As a pet store user I want modifying my existing pets so that I can update their name or/and status.
	 * Acceptance Criteria: 
	 * 1. Pet edit should be possible by clicking on pet name or pet status
	 * 2. Clicking outside the edition zone => Changes should be saved.
	 * @version 1.0
	 */
	@Test(dataProvider="PetDetailsUpdate")
	public void US004_UpdatePetsClick(String CurrentName,String UpdatedName,String CurrentStatus,String UpdatedStatus)
	{
		PetStore_UpdatePet PU = new PetStore_UpdatePet(driver);
		int rowNum = PU.getRowNum(CurrentName,CurrentStatus);
		PU.updatePetNameStatusClick(rowNum,UpdatedName,UpdatedStatus);
		PU.validateUpdate(rowNum,UpdatedName,UpdatedStatus);
		
	}
	
	/**
	 * @author Akash Sinha 
	 * @desciption As a pet store user I want modifying my existing pets so that I can update their name or/and status.
	 * Acceptance Criteria: 
	 * 1. Pet edit should be possible by clicking on pet name or pet status
	 * 2. Pressing the Esc key => Changes should be discarded.
	 * @version 1.0
	 */
	@Test(dataProvider="PetDetailsUpdate")
	public void US004_UpdatePetsEsc(String CurrentName,String UpdatedName,String CurrentStatus,String UpdatedStatus)
	{
		PetStore_UpdatePet PU = new PetStore_UpdatePet(driver);
		int rowNum = PU.getRowNum(CurrentName,CurrentStatus);
		PU.updatePetNameStatusEsc(rowNum,UpdatedName,UpdatedStatus);
		PU.validateUpdateEsc(rowNum,CurrentName,CurrentStatus);
		
	}
	
	/**
	 * @author Akash Sinha 
	 * @desciption Data Provider For US003 Test Cases
	 * @version 1.0
	 */
	@DataProvider(name="PetDataAdd")
	public Object[][] petDetails()
	{
		Object[][] petData;
		//String path = "H:\\Petstore Assignment\\Petstore-Assignment\\src\\DataTable\\AddPet.xlsx";
		DataProviderPet dp = new DataProviderPet();
		petData = dp.dpProvider(System.getProperty("user.dir")+"\\src\\DataTable\\AddPet.xlsx");
		return petData;
		
	}
	
	/**
	 * @author Akash Sinha 
	 * @desciption Data Provider For US002 Test Cases
	 * @version 1.0
	 */
	@DataProvider(name="PetDetailsView")
	public Object[][] petView()
	{
		Object[][] petData;
		//String path = "H:\\Petstore Assignment\\Petstore-Assignment\\src\\DataTable\\ViewPet.xlsx";
		DataProviderPet dp = new DataProviderPet();
		petData = dp.dpProvider(System.getProperty("user.dir")+"\\src\\DataTable\\ViewPet.xlsx");
		return petData;
		
	}
	
	/**
	 * @author Akash Sinha 
	 * @desciption Data Provider For US004 Test Cases
	 * @version 1.0
	 */
	@DataProvider(name="PetDetailsUpdate")
	public Object[][] petUpdate()
	{
		Object[][] petData;
		//String path = "H:\\Petstore Assignment\\Petstore-Assignment\\src\\DataTable\\UpdatePet.xlsx";
		DataProviderPet dp = new DataProviderPet();
		petData = dp.dpProvider(System.getProperty("user.dir")+"\\src\\DataTable\\UpdatePet.xlsx");
		return petData;
		
	}

}
