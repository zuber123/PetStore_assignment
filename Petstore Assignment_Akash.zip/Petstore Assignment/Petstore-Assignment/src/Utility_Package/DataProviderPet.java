/**
 * 
 */
package Utility_Package;
/**
 * @author Akash Sinha 
 * @desciption This Class is to get Data in Data Provider
 * @version 1.0
 */
import Utility_Package.ReadExcel;

public class DataProviderPet {
	//Read the Data Provider and Create an Object of Array
	public Object[][] dpProvider(String path)
	{
		int rowNum;
		int colNum;
		int i,j;
		int k=0;
		String cellData;
		ReadExcel excel = new ReadExcel(path);
		rowNum = excel.RowNumber();
		colNum = excel.ColumnNumber();
		Object[][] data = new Object[rowNum][colNum];
	
		for(i=1;i<=rowNum;i++)
		{
			for(j=0;j<colNum;j++)
			{
				cellData = excel.getData(i, j);
				data[k][j]= cellData;
						
			
			}
			k=k+1;
			
		}
		excel.closeExcel();	
		return data;
	}
}
