/**
 * 
 */
package Utility_Package;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * @author Akash Sinha 
 * @desciption This Class is to get Data from Excel Sheet
 * @version 1.0
 */
public class ReadExcel {
	//Read the Excel sheet using Apache POI library
	XSSFWorkbook wb;
	XSSFSheet sheet;
	int rowNum;
	int colNum;
	public ReadExcel(String excelPath) {
		try {
			File src = new File(excelPath);
			
			FileInputStream fis = new FileInputStream(src);
			 wb = new XSSFWorkbook(fis);
			 sheet = wb.getSheet("Sheet1");
		} 
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();	
			
		}
	}
	public int RowNumber()
	{
		rowNum = sheet.getLastRowNum();
		return rowNum;
		
	}
	
	public int ColumnNumber()
	{
		colNum = sheet.getRow(0).getPhysicalNumberOfCells();
		return colNum;
		
	}
	
	public String getData(int i, int j)
	{
		String cellData = sheet.getRow(i).getCell(j).getStringCellValue();
		return cellData;
		
	}
	
	public void closeExcel()
	{
		try {
			wb.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
