package Utility_Package;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
/**
 * @author Akash Sinha 
 * @desciption This Class is to get Browser and Launch the URL
 * @version 1.0
 */
public class BrowserFactory {
	//Select the browser Chrome, ie or Firefox and launch the URL
	WebDriver driver;
	public WebDriver selectBrowser(String DriverName,String URL)
	{
		if(DriverName.trim().equals("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\src\\Driver\\chromedriver.exe");
			driver = new ChromeDriver();
		}
		if(DriverName.trim().equals("ie"))
		{
				System.setProperty("webdriver.ie.driver", System.getProperty("user.dir")+"\\src\\Driver\\IEDriverServer.exe");
				driver = new InternetExplorerDriver();
				
			}
		if(DriverName.trim().equals("firefox"))
		{
			
			driver = new FirefoxDriver();
		}
		
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get(URL.trim());
			
		return driver;
		
	}
	

}
