package PageObjaectModel_Package;
/**
 * @author Akash Sinha 
 * @desciption This Class is having all the methods and Elements which are related to 
 * Web Table of PetStore Application
 * @version 1.0
 */
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

/**
 * @author Akash Sinha 
 * @desciption To validate all the pets present on a page
 * @version 1.0
 */

public class PetStore_PetTable {

	WebDriver driver;
	SoftAssert assertion = new SoftAssert();
	WebElement name1,status1;
	//Element and Their locators sotred using @FindBy annotation i.e. Pageobjectr model with PageFactory
	@CacheLookup
	@FindBy(how=How.XPATH,xpath="//thead[@class='thead-default']/tr[1]/th[1]")
	WebElement NameHeader;
	
	@CacheLookup
	@FindBy(how=How.XPATH,xpath="//thead[@class='thead-default']/tr[1]/th[2]")
	WebElement StatusHeader;
	
	@CacheLookup
	@FindBy(how=How.XPATH,xpath="//thead[@class='thead-default']/tr[1]/th[3]")
	WebElement ActionHeader;
	
	@CacheLookup
	@FindBy(how=How.XPATH,xpath="//h3[text()='List of Pets']")
	WebElement ListOfPetsHeader;
	
	//initializing Pagefactory elements
public PetStore_PetTable(WebDriver driver)
{
	PageFactory.initElements(driver, this);
	this.driver = driver;
	}
	

//Verify the Name Status and Action Header of Web Table
public void TableHeading(){
	try{
		assertion.assertEquals(NameHeader.getText().trim(),"Name","Name header field is not as expected");
		assertion.assertEquals(StatusHeader.getText().trim(),"Status","Status header field is not as expected");
		assertion.assertEquals(ActionHeader.getText().trim(),"Action","Action header field is not as expected");
		assertion.assertAll();			
		}catch(Exception e){
			e.printStackTrace();
		}		
		}

//Verify that correct Name and Status are being displayed on the WebPage of PetStore
public void validatePetNameStatus(int getRow,String Name,String Status)
{
	
	if(getRow>0)
	{
		name1 = driver.findElement(By.xpath("//table[@class='table table-hover']/tbody[@class='pet-list']//tr["+getRow+"]//td[1]"));
		String actualName = name1.getText();
		status1 = driver.findElement(By.xpath("//table[@class='table table-hover']/tbody[@class='pet-list']//tr["+getRow+"]//td[2]"));
		String actualStatus = status1.getText();
		Assert.assertEquals(actualName, Name,"Name is not being updated as expected");
		Assert.assertEquals(actualStatus, Status,"Status is not being updated as expected");
	}
	else{
		Assert.fail("Your Pet has not been found in PetList");
	}
	
	
}

//Verify the List Of Pets Header of the WebTable
public void ListOfPetsHeader(){
	assertion.assertTrue(ListOfPetsHeader.isDisplayed(),"List of Pets Heading is not as expected");
	assertion.assertAll();
}
}