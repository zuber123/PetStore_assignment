package PageObjaectModel_Package;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
/**
 * @author Akash Sinha 
 * @desciption This Class is having all the methods and Elements which are related to 
 * Header of PetStore Application
 * @version 1.0
 */
public class PetStore_Header {
	
	WebDriver driver;
	//Element and Their locators sotred using @FindBy annotation i.e. Pageobjectr model with PageFactory
	@CacheLookup
	@FindBy(how=How.XPATH,xpath="//span[@class='banner-date']//div[1]")
	WebElement TodayDate;
	
	@CacheLookup
	@FindBy(how=How.XPATH,xpath="//nav[@class='assignment-nav']")
	WebElement BackroundBanner;
	
	//initializing Pagefactory elements
	public PetStore_Header(WebDriver driver) {
		
		PageFactory.initElements(driver,this);
	}
	
	//Get Today's date from System in DD-MM-YYYY format
	public String getExpectedDate()
	{	
		//Date class object to get Today'sdate
		Date date = new Date();
				
		
		//SimpleDateFormate for formating today's date as dd-MM-yyyy
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		String ExpectedDate = sdf.format(date);
		return ExpectedDate;
	}
	
	//Get Date displayed on the Pet Store Applicaiton web page
	public String getActualDate()
	{	
		String ActualDate = TodayDate.getText();
		return ActualDate;
	}
	
	//Get Banner Color displayed on the  Web Page of PetStore Applicaiton
	public String getActualColor()
	{
		//To get BackgrounfBanner Color
		String Color = BackroundBanner.getCssValue("color");
				
		//To convert rgba color in hex value
		String[] hexValue = Color.replace("rgba(", "").replace(")", "").split(",");

		int hexValue1=Integer.parseInt(hexValue[0]);
		hexValue[1] = hexValue[1].trim();
		int hexValue2=Integer.parseInt(hexValue[1]);
		hexValue[2] = hexValue[2].trim();
		int hexValue3=Integer.parseInt(hexValue[2]);
				
		//keeping all the Hexvalues in the #202020 format
		String ActualColor = String.format("#%02x%02x%02x", hexValue1, hexValue2, hexValue3);
		
		return ActualColor;
		
	}
	
	//Get color from the CSS file of webpage
	public String getExpectedColor()
	{
		
		//keeping the actual value which is present in the CSS file of the webpage
		String ExpectedColor = "#373a3c";
		return ExpectedColor;
	}
	
	//Get Location of Date displayed on the Petstore application
	public void getLocation(){
		Point BannerLoc = TodayDate.getLocation();
		Assert.assertEquals(BannerLoc.getX(),309);
		Assert.assertEquals(BannerLoc.getY(),20);
	}
	
	
}
