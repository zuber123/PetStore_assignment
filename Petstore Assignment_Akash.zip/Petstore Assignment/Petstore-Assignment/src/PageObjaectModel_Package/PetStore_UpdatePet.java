package PageObjaectModel_Package;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
/**
 * @author Akash Sinha 
 * @desciption This Class is having all the methods and Elements which are related to 
 * Update the Pet in Pet Store application
 * @version 1.0
 */
public class PetStore_UpdatePet {

WebDriver driver;

WebElement name,name1,nmclick;
WebElement status,status1,stsclick;
By name2,status2;
//Element and Their locators sotred using @FindBy annotation i.e. Pageobjectr model with PageFactory
@CacheLookup
@FindBy(how=How.XPATH,xpath="//table[@class='table table-hover']/tbody[@class='pet-list']")
WebElement TBody;

@CacheLookup
@FindBy(how=How.XPATH,xpath="//h3[@class='card-title']")
WebElement TableTitle;
//initializing Pagefactory elements
	public PetStore_UpdatePet(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
		this.driver = driver;
		
	}
	//Get Row Number on which we have to update the Name and Status
	public int getRowNum(String CurrentName,String CurrentStatus)
	{
		int i;
		int getRow=0;
		List<WebElement> petList = TBody.findElements(By.tagName("tr"));
		int RowNum = petList.size();
		for(i=0;i<RowNum;i++)
		{
			List<WebElement> petNameStatus = petList.get(i).findElements(By.tagName("td"));
			if(CurrentName.equals(petNameStatus.get(0).getText().trim()))
			{
				if(CurrentStatus.equals(petNameStatus.get(1).getText().trim()))
				{
					getRow=i+1;
					break;
				}
			}
			
		}
		return getRow;
		
		
	}
	//UPdate the Pet Name and Status by clicking on the Enter Key
	public void updatePetNameStatusEnter(int getRow,String UpdatedName,String UpdatedStatus) throws Throwable
	{
		
		if(getRow>0)
		{
			WebDriverWait wait = new WebDriverWait(driver, 10);
			name = driver.findElement(By.xpath("//tr["+getRow+"]/td[1]"));
			name.click();
			name1 = driver.findElement(By.xpath("//tr["+getRow+"]/td[1]/input"));
			name1.clear();
			name1.sendKeys(UpdatedName);
			name1.sendKeys(Keys.ENTER);
			//wait.until(ExpectedConditions.stalenessOf(name));
			
			status = driver.findElement(By.xpath("//tr["+getRow+"]/td[2]"));
			status.click();
			status1 = driver.findElement(By.xpath("//tr["+getRow+"]/td[2]/input"));
			status1.clear();
			status1.sendKeys(UpdatedStatus);
			status1.sendKeys(Keys.ENTER);			
			wait.until(ExpectedConditions.stalenessOf(status));
		}
		else{
			Assert.fail("Your Pet has not been found in PetList");
		}
		
		
	}
	
	//UPdate the Pet Name and Status by clicking on the Out of the edition zone
	public void updatePetNameStatusClick(int getRow,String UpdatedName,String UpdatedStatus)
	{
		if(getRow>0)
		{
			
			WebDriverWait wait = new WebDriverWait(driver, 10);
			name = driver.findElement(By.xpath("//tr["+getRow+"]/td[1]"));
			name.click();
			name1 = driver.findElement(By.xpath("//tr["+getRow+"]/td[1]/input"));
			name1.clear();
			name1.sendKeys(UpdatedName);
			
			TableTitle.click();
			//wait.until(ExpectedConditions.stalenessOf(name));
			
			status = driver.findElement(By.xpath("//tr["+getRow+"]/td[2]"));
			status.click();
			status1 = driver.findElement(By.xpath("//tr["+getRow+"]/td[2]/input"));
			status1.clear();
			status1.sendKeys(UpdatedStatus);
			
			TableTitle.click();
			
			wait.until(ExpectedConditions.stalenessOf(status));
		}
		else{
			Assert.fail("Your Pet has not been found in PetList");
		}
		
		
	}
	//Discard the update by click on the Escape Button
	public void updatePetNameStatusEsc(int getRow,String UpdatedName,String UpdatedStatus)
	{
		if(getRow>0)
		{
			name = driver.findElement(By.xpath("//tr["+getRow+"]/td[1]"));
			name.click();
			name1 = driver.findElement(By.xpath("//tr["+getRow+"]/td[1]/input"));
			name1.clear();
			name1.sendKeys(UpdatedName);
			name1.sendKeys(Keys.ESCAPE);
			
			status = driver.findElement(By.xpath("//tr["+getRow+"]/td[2]"));
			status.click();
			status1 = driver.findElement(By.xpath("//tr["+getRow+"]/td[2]/input"));
			status1.clear();
			status1.sendKeys(UpdatedStatus);
			status1.sendKeys(Keys.ESCAPE);
			
		}
		else{
			Assert.fail("Your Pet has not been found in PetList");
		}
		
		
	}
	//Validate the updated value of Name and Status
	public void validateUpdate(int getRow,String UpdatedName,String UpdatedStatus)
	{
			name = driver.findElement(By.xpath("//tr["+getRow+"]/td[1]"));
			status = driver.findElement(By.xpath("//tr["+getRow+"]/td[2]"));
		    
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.elementToBeClickable(name));
			wait.until(ExpectedConditions.elementToBeClickable(status));
			String actualName = name.getText();
			String actualStatus = status.getText();
			Assert.assertEquals(actualName, UpdatedName,"Name is not being updated as expected");
			Assert.assertEquals(actualStatus, UpdatedStatus,"Status is not being updated as expected");
		
		
	}
	
	//Validate that after Escape button Name and Status is not getting updated
	public void validateUpdateEsc(int getRow,String CurrentName,String CurrentStatus)
	{
		String actualName = driver.findElement(By.xpath("//table[@class='table table-hover']/tbody[@class='pet-list']//tr["+getRow+"]//td[1]")).getText();
		String actualStatus = driver.findElement(By.xpath("//table[@class='table table-hover']/tbody[@class='pet-list']//tr["+getRow+"]//td[2]")).getText();
		Assert.assertEquals(actualName, CurrentName,"Name is updated i.e not as expected");
		Assert.assertEquals(actualStatus, CurrentStatus,"Status is updated i.e not as expected");
		
	}

}
