package PageObjaectModel_Package;
/**
 * @author Akash Sinha 
 * @desciption This Class is having all the methods and Elements which are related to 
 * Home Page of PetStore Application
 * @version 1.0
 */
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

public class PetStore_HomePage {
	
	WebDriver driver;
	//Element and Their locators sotred using @FindBy annotation i.e. Pageobjectr model with PageFactory
	@CacheLookup
	@FindBy(how=How.XPATH,xpath="//input[@class='form-control pet-name']")
	WebElement petName;
	
	@CacheLookup
	@FindBy(how=How.XPATH,xpath="//input[@class='form-control pet-status']")
	WebElement petStatus;
	
	@CacheLookup
	@FindBy(how=How.ID,id="btn-create")
	WebElement createButton;
	
	@CacheLookup
	@FindBy(how=How.XPATH,xpath="//table[@class='table table-hover']/tbody/tr")
	WebElement petTable;
	//initializing Pagefactory elements
	public PetStore_HomePage(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
		this.driver = driver;
		
	}
	
	//Enter Pet Details like Name Status and Click on Create Button
	public void enterPetDetails(String Name, String Status)
	{
		petName.sendKeys(Name);
		petStatus.sendKeys(Status);
		createButton.click();
		
	}
	
	//Enter Pet Details like Name Status and Hit the Enter Key of the keyboard
	public void enterPetDetailsEnter(String Name, String Status)
	{
		petName.sendKeys(Name);
		petStatus.sendKeys(Status);
		petStatus.sendKeys(Keys.ENTER);
		
	}
	
	//Verify Pet Accessibility by pressing Tab key and navigate to Name, Status and Button
	public void verifyPetAccesbility()
	{
		
		petName.sendKeys();
		
		Assert.assertEquals(driver.switchTo().activeElement(), petName,"petName is not in Focus");
		petName.sendKeys(Keys.TAB);
		
		Assert.assertEquals(driver.switchTo().activeElement(), petStatus,"petStatus is not in Focus");
		petStatus.sendKeys(Keys.TAB);
		Assert.assertEquals(driver.switchTo().activeElement(), createButton,"createButton is not in Focus");
		
	}
	
	//Validate the Pet Entry added on the page, is getting displayed or not
	public void validatePetEntry(String Name,String Status,int rowCount)
	{
		SoftAssert assertion = new SoftAssert();
		String ptName = driver.findElement(By.xpath("//table[@class='table table-hover']/tbody/tr["+rowCount+"]/td[1]")).getText();
		String ptStatus = driver.findElement(By.xpath("//table[@class='table table-hover']/tbody/tr["+rowCount+"]/td[2]")).getText();
		assertion.assertEquals(ptName,Name,"Names are not matched. Expected name is "+Name+" and actual name is "+ptName+". So applicaiton is not working properly while Adding pets");
		assertion.assertEquals(ptStatus,Status,"Status are not matched. Expected status is "+Status+" and actual status is "+ptStatus+". So applicaiton is not working properly while Adding pets");
		assertion.assertAll();
	}
	
	//Validate the Pet Empty Entry added on the page, is not getting displayed or not
		public void validatePetEntryEmpty(String Name,String Status,int rowCount)
		{
			SoftAssert assertion = new SoftAssert();
			String ptName = driver.findElement(By.xpath("//table[@class='table table-hover']/tbody/tr["+rowCount+"]/td[1]")).getText();
			String ptStatus = driver.findElement(By.xpath("//table[@class='table table-hover']/tbody/tr["+rowCount+"]/td[2]")).getText();
			assertion.assertNotEquals(ptName,Name,"Names are matched. Expected name is not empty but actual name is Empty So name field is not mandatory field which is not as expected");
			assertion.assertNotEquals(ptStatus,Status,"Status are matched. Expected status is not empty but actual status is Empty So status field is not mandatory field which is not as expected");
			assertion.assertAll();
		}
	
	//Getting the total row count of web table
	public int getWebtableRowcount()
	{
		int rCount = driver.findElements(By.xpath("//table[@class='table table-hover']/tbody/tr")).size();
		return rCount;
	}
	//Wait explicitly until the row to be added
	public void waitWhenVisible(By locator, int timeout) {

		WebDriverWait wait = new WebDriverWait(driver, timeout);
		WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));

	}
	//validate row count
	public void validateRowCount(int beforeRowCount,int afterRowCount)
	{
		SoftAssert assertion = new SoftAssert();
		int diffRowCount = afterRowCount - beforeRowCount;
		assertion.assertEquals(diffRowCount, 1,"Difference of the rowcount is not 1 so applicaiton is not working properly while adding the pet");
		assertion.assertAll();
	}


}
