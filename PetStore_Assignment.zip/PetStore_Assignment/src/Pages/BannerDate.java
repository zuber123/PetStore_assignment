
package Pages;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
//import org.testng.Assert;
import org.testng.asserts.SoftAssert;

/**
 * @author Zuber Qureshi
 * @description Home page of petstore application
 * @version 1.0
 */

public class BannerDate {
	
	WebDriver driver;
	SoftAssert assert1;
	
	@CacheLookup
	@FindBy(xpath="//span[@class='banner-date']//div[1]")
	WebElement BannerDate;

	@CacheLookup
	@FindBy(xpath="//div[@class='assignment-masthead']")
	WebElement BannerColor;

	//Function to set the XPaths of Home page
	public void setxpathsonHomePage(WebDriver driver){
	PageFactory.initElements(driver,this);
	this.driver=driver;
	assert1 = new SoftAssert();
}

	//Function to check Banner Date Format
public void BannerDateFormat(){		
	DateFormat Dateformat = new SimpleDateFormat("dd-MM-yyyy");
	Date date1 = new Date();		
	assert1.assertEquals(Dateformat.format(date1),BannerDate.getText(),"Date is not as expected");
	assert1.assertAll();
}

//Function to check Banner Color
public void BannerColor(){
	  String text = BannerColor.getCssValue("background-color");
	
	  //Split css value of rgb
	  String[] numbers = text.replace("rgba(", "").replace(")", "").split(",");
	  
	  int number1=Integer.parseInt(numbers[0]);	  
	  numbers[1] = numbers[1].trim();
	  
	  int number2=Integer.parseInt(numbers[1]);
	  numbers[2] = numbers[2].trim();
	  
	  int number3=Integer.parseInt(numbers[2]);
	  
	  String hex = String.format("#%02x%02x%02x", number1,number2,number3);
	  assert1.assertEquals(hex, "#333333","Color is not black");
	  assert1.assertAll();
}

//Function to check Date location on web page
public void getLocation(){
	Point BannerLoc = BannerDate.getLocation();
	assert1.assertEquals(BannerLoc.getX(),268,"The Banner date has moved either up or down from its original position");
	assert1.assertEquals(BannerLoc.getY(),28,"The Banner date has moved either to the right or left from its original position");
	assert1.assertAll();
	}
}
