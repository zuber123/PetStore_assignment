/**
 * 
 */
package Pages;



import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

/**
 * @author Zuber Qureshi
 * @description created to laucn the application
 * @version 1.0
 */

public class BrowserFactory {

WebDriver driver;

//Function to Launch application
	public WebDriver LaunchApp(String browser, String url){
		//System.out.println("hii");
		if(browser.equalsIgnoreCase("firefox")){
				driver = new FirefoxDriver();	
		}
		
		if(browser.equalsIgnoreCase("chrome")){
			System.setProperty("webdriver.chrome.driver", "F:\\Software\\chromedriver_win32\\chromedriver.exe");
			driver = new ChromeDriver();	
			
		}
		
		if(browser.equalsIgnoreCase("ie")){
			driver = new InternetExplorerDriver();	
		}
		driver.manage().window().maximize();
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        return driver;
	}	


}

