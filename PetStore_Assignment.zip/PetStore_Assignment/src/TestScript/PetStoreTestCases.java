package TestScript;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import Pages.AddPets;
import Pages.BannerDate;
import Pages.BrowserFactory;
import Pages.DataProvider1;
import Pages.ModifyPetDetails;
import Pages.PetDetails;


/**
 * @author Zuber
 * @description Test suite of petstore test cases
 * @version 1.0
 **/

public class PetStoreTestCases {

	WebDriver driver;	
		
/**Before Method created to launch the Browser
**/
@BeforeMethod
public void LauchApplication(){
	try{		
			BrowserFactory BF = new BrowserFactory();
			driver = BF.LaunchApp("chrome", "http://localhost:3000/");
		}catch(Exception e){
		e.printStackTrace();
	}
}

/**After Method created to close the Browser
**/
@AfterMethod
public void CloseBrowser(){
	try{
		driver.close();
	}catch(Exception e){
		e.printStackTrace();
	}	
}

/**DataProvider created to get the data from the DataTable
 * This particular DataTable is used to get the Pet Details i.e. Name and Status of the pet
 **/
@DataProvider(name="PetDetails")
public Object[][] GetPetDetailsFormDetaTable(){
	DataProvider1 DP = new DataProvider1();
	Object[][] PetDet = DP.DataFromDataTable("E:\\Selenium\\New folder\\PetStore_Assignment\\src\\DataTable\\PetDetails_Name_Status.xls");
	return PetDet;
}

/**DataProvider created to get the data from the DataTable
 * This particular DataTable is used to get the Pet Details i.e. Name and Status of the pet
 **/
@DataProvider(name="AddPets")
public Object[][] GetPetDetailsToAdd(){
	DataProvider1 DP = new DataProvider1();
	Object[][] PetDet = DP.DataFromDataTable("E:\\Selenium\\New folder\\PetStore_Assignment\\src\\DataTable\\AddPets.xls");
	return PetDet;
}

/**DataProvider created to get the data from the DataTable
 * This particular DataTable is used to get the Pet Details i.e. Name and Status of the pet
 **/
@DataProvider(name="UpdatePets")
public Object[][] UpdatePetDetailsToAdd(){
	DataProvider1 DP = new DataProvider1();
	Object[][] PetDet = DP.DataFromDataTable("E:\\Selenium\\New folder\\PetStore_Assignment\\src\\DataTable\\UpdatePets.xls");
	return PetDet;
}


/**Test Case Name: US0001 - Viewing the current date
 * Description: As a pet store user I want to see the current date displayed on the top banner so that I can easily see it.
 * Acceptance Criteria: Date is displayed on the format DD-MM-YYYY, ie: 01-12-2016
 * The background color of the banner is black
 **/	
@Test
public void VerifyBannerDateDetails(){
	try{
	BannerDate BD = new BannerDate();
	BD.setxpathsonHomePage(driver);
	BD.BannerDateFormat();	
	BD.BannerColor();
	BD.getLocation();
	}catch(Exception e){
		e.printStackTrace();
	}
}


/**Test Case Name: US0002 - Viewing my pets
 * Description: As a pet store user I want to see my current pets so that I can view all my pets in one page.
 * Acceptance Criteria: List of pets displayed in a table like component
 * I need to be able to easily identify my pets Name and Status
 * Ensure the component can load up to 100 pets in a single page in less than 2 seconds (on any developer machine)	 
 **/
@Test(dataProvider="PetDetails")
public void ViewPets(String Name,String Status){
	try{
		PetDetails details = new PetDetails(driver);
		details.TableHeading();
		details.TableData(Name,Status);
		details.ListOfTableHead();
		}catch(Exception e){
			e.printStackTrace();
		}
	}



/**Test Case Name: US0003 - Adding pets
 * Description: As a pet store user I want to see my current pets so that I can view all my pets in one page.
 * Acceptance Criteria: List of pets displayed in a table like component
 * I need to be able to easily identify my pets Name and Status
 * Ensure the component can load up to 100 pets in a single page in less than 2 seconds (on any developer machine)	 
 **/
@Test(dataProvider="AddPets")
public void AddPet(String Name,String Status){
	try{
		AddPets AddP = new AddPets(driver);
		AddP.AddPetByClick(Name, Status);
		AddP.ValidateAddedPet(Name, Status);
		AddP.ValidateAddOrUpdatePets(Name, Status);	
		AddP.TabUseAndEnterKeyToAddPet(Name, Status);
		AddP.ValidateAddedPet(Name,Status);
		AddP.ValidateAddOrUpdatePets(Name, Status);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

/**Test Case Name: US0003 - Validating Mandatory
 * Description: As a pet store user I want to see my current pets so that I can view all my pets in one page.
 * Acceptance Criteria: List of pets displayed in a table like component
 * I need to be able to easily identify my pets Name and Status
 * Ensure the component can load up to 100 pets in a single page in less than 2 seconds (on any developer machine)	 
 **/
@Test
public void ValidateMandatoryFileds(){
	try{
		AddPets AddP = new AddPets(driver);
		AddP.ValidateMandatoryFields();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

/**Test Case Name: US0004 - Modifying an existing pet 
 * Description: As a pet store user I want modifying my existing pets so that I can update their name or/and status.
 * Acceptance Criteria: Pet edit should be possible by clicking on pet name or pet status
 * 3 ways to quit the editing of a pet 
 * Pressing the Esc key => Changes should be discarded.
 * Pressing the Enter key => Changes should be saved.
 * Clicking outside the edition zone => Changes should be saved.	 
 **/
@Test(dataProvider="UpdatePets")
public void ModifyPets(String Name,String Status,String UpdateName, String UpdateStatus){
	try{
		ModifyPetDetails ModifyPet = new ModifyPetDetails();
		int row = ModifyPet.RowNoToUpdate(Name, Status,driver);
		ModifyPet.setUpPage(row);
		ModifyPet.UpdateByPressingEnter(UpdateName,UpdateStatus,row);
		ModifyPet.setUpPage(row);
		ModifyPet.validateUpdate(row,UpdateName, UpdateStatus);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

/**Test Case Name: US0004 - Modifying an existing pet 
 * Description: As a pet store user I want modifying my existing pets so that I can update their name or/and status.
 * Acceptance Criteria: Pet edit should be possible by clicking on pet name or pet status
 * 3 ways to quit the editing of a pet 
 * Pressing the Esc key => Changes should be discarded.
 * Pressing the Enter key => Changes should be saved.
 * Clicking outside the edition zone => Changes should be saved.	 
 **/
@Test(dataProvider="UpdatePets")
public void ModifyPetswithESc(String Name,String Status,String UpdateName, String UpdateStatus){
	try{
		ModifyPetDetails ModifyPet = new ModifyPetDetails();
		
		int row = ModifyPet.RowNoToUpdate(Name, Status,driver);
		ModifyPet.setUpPage(row);
		ModifyPet.UpdateByPressingESC(UpdateName, UpdateStatus, row);
		ModifyPet.setUpPage(row);
		ModifyPet.UpdateByClickingOnOpenArea(UpdateName, UpdateStatus, row);
		ModifyPet.setUpPage(row);
		ModifyPet.validateUpdate(row,UpdateName, UpdateStatus);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}

